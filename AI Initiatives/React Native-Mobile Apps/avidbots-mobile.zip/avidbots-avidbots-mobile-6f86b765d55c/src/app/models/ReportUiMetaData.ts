  interface ReportUiMetaData {
    title: string;
    icon: string;
    label: string;
    value: string | null;
    info: string | null;
  }

export default ReportUiMetaData;