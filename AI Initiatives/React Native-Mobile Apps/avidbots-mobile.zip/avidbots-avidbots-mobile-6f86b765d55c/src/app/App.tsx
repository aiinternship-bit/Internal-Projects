import { ThemeProvider } from '@rneui/themed';
import { Router } from './navigations/index';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { RootSiblingParent } from 'react-native-root-siblings';
import { useEffect, useState } from 'react';
import NetInfo from '@react-native-community/netinfo';
import { NetworkErrorScreen } from './components/NetworkErrorScreen';
import { GlobalContextProvider } from './contexts/GlobalContext';
import { ThemeContextProvider } from './contexts/ThemeContext';
import { PermissionsAndroid, Platform } from 'react-native';
import messaging from '@react-native-firebase/messaging';
import { theme } from '../theme';
import { Provider } from 'react-redux';
import { store } from 'store';
import SplashScreen from 'react-native-splash-screen';

/**
 * ? Here App/Device Level Providers can be specified
 * @returns Root App Component
 */

const App = () => {
  const [isConnected, setIsConnected] = useState<boolean | null>(true);
  const checkInternetConnection = () => {
    NetInfo.refresh().then((state) => {
      setIsConnected(state.isConnected);
    });
  };

  const requestUserPermission = async () => {
    const authStatus = await messaging().requestPermission();
    const enabled =
      authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authStatus === messaging.AuthorizationStatus.PROVISIONAL;
    if (enabled) {
      return;
    }
  };

  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide(); //hides the splash screen on app load.
    }, 1400);
    if (Platform.OS === 'android') {
      PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATION)
        .then((res) => {
          if (!!res && (res === 'granted' || res === 'never_ask_again')) {
            requestUserPermission();
          }
        })
        .catch((err) => {
          return err;
        });
    } else {
      requestUserPermission();
    }
  }, []);

  // Subscribe to network state updates:
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      setIsConnected(state.isConnected);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const ThemeProviderContainer = () => {
    return (
      <ThemeProvider theme={theme}>
        <RootSiblingParent>
          {!isConnected ? (
            <NetworkErrorScreen checkInternetConnection={checkInternetConnection} />
          ) : (
            <Provider store={store}>
              <Router />
            </Provider>
          )}
        </RootSiblingParent>
      </ThemeProvider>
    );
  };

  return (
    <GlobalContextProvider>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <ThemeContextProvider>
          <ThemeProviderContainer />
        </ThemeContextProvider>
      </GestureHandlerRootView>
    </GlobalContextProvider>
  );
};

export default App;
