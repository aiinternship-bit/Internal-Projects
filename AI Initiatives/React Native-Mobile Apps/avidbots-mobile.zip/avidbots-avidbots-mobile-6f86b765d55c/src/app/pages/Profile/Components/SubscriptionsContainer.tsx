import { Text } from '@rneui/themed';
import { View } from 'react-native';

export const SubscriptionsContainer = () => {
	return (
		<View>
			<Text>SubscriptionsContainer</Text>
		</View>
	);
};