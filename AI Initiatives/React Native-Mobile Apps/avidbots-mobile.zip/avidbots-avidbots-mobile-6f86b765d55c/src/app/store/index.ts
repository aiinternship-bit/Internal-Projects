import store, {RootState} from './store';

export {store};
export type {RootState};
