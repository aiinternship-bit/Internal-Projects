
import { createNavigationContainerRef, DefaultTheme, NavigationContainer } from '@react-navigation/native';

import { AppStack } from './AppStack';
import { AuthStack } from './AuthStack';
import { AuthContext } from 'contexts/Auth';
import { useContext, useEffect, useState } from 'react';
import { PanResponder, SafeAreaView } from 'react-native';
import { EulaStack } from './EulaStack';
import { ChatProvider } from 'contexts/ChatContext';
import { useTheme } from '@rneui/themed';
import { useSessionContext } from 'contexts/SessionContext';
import { SessionModal } from 'components/Modals/SessionModal';
import { useDomainContext } from 'contexts/DomainContext';
import { FullPageLoader } from 'components/Loader/Loader';
import { useGlobalContext } from 'contexts/GlobalContext';
import { getVersion } from 'react-native-device-info';
import { FirebaseProvider } from 'contexts/Notifications';
import ErrorBoundary from 'components/ErrorBoundary';

/**
	* ? App should have only one NavigationContainer
	* ? Providers that relate with user/api interaction can be specified here
	* @returns Navigation Container for the whole App
	*/

export const Router = () => {
	const { authData, eulaFlag, signOut } = useContext(AuthContext);
	const { isSessionTimeOut, isAppInactive, setSessionTimeOut, setAppInactive, appInactivityCheck, navigationListeners, appRevoking } = useSessionContext();
	const { domain } = useDomainContext();
	const { currentVersion, setIsAppDeprecated } = useGlobalContext();
	const [isAppReadyToLoad, setAppReadyToLoad] = useState(false);

	const { theme } = useTheme();

	//react navigation uses default theme, updating it with transparent background
	const authStackTheme = {
		...DefaultTheme,
		colors: {
			...DefaultTheme.colors,
			background: 'transparent',
		},
	};

	useEffect(() => {
		if (domain !== '') {
			setAppReadyToLoad(true);
		}
	}, [domain]);

	useEffect(() => {
		if (isSessionTimeOut || isAppInactive) {
			if (authData) {
				signOut();
				setSessionTimeOut(false);
			}
		}
	}, [isSessionTimeOut, isAppInactive]);

	useEffect(() => {
		if (authData) {
			navigationListeners();
			appInactivityCheck();
		}
		if (authData === undefined) {
			isSessionTimeOut ? setSessionTimeOut(false) : setAppInactive(false);
		}

	}, [authData]);

	useEffect(() => {
		const _appVersion = getVersion();
		if (currentVersion === '') return;
		if (_appVersion !== currentVersion) {
			setIsAppDeprecated(true);
		}
	}, [currentVersion]);


	const panResponder = PanResponder.create({
		onStartShouldSetPanResponder: () => { if (authData) { appInactivityCheck(); } return false; },
		onStartShouldSetPanResponderCapture: () => { if (authData) { appInactivityCheck(); } return false; }
	});


	return (
		<ErrorBoundary>
			<NavigationContainer ref={navigationRef} theme={authData ? theme : authStackTheme}>
				<SafeAreaView {...panResponder.panHandlers} style={{ width: '100%', height: '100%' }}>
					{appRevoking ? <FullPageLoader /> : <></>}
					{(isSessionTimeOut || isAppInactive) ? <SessionModal /> : <></>}
					{isAppReadyToLoad && authData ?
						<FirebaseProvider>
							<ChatProvider>
								{eulaFlag ? <AppStack /> : <EulaStack />}
							</ChatProvider>
						</FirebaseProvider>
						: <AuthStack />}
				</SafeAreaView>
			</NavigationContainer>
		</ErrorBoundary>
	);
};

export const navigationRef = createNavigationContainerRef();