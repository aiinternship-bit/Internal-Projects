export const reportStatus = {
  success: 'success',
  partial: 'partial',
  avidbots_cancelled: 'avidbots_cancelled',
  operator_cancelled: 'operator_cancelled',
};
