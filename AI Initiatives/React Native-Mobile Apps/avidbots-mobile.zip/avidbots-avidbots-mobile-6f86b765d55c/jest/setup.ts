jest.mock('@rneui/themed', () => {
 return {
  useTheme: jest.fn().mockImplementation(() => {
   return {
    theme: {
     colors: {},
     background: {},
    },
   };
  }),
  createTheme: jest.fn(),
  useThemeMode: jest.fn().mockImplementation(() => ({ setMode: jest.fn() })),
  Text: jest.fn(),
 };
});

jest.mock('@react-native-async-storage/async-storage', () =>
 require('@react-native-async-storage/async-storage/jest/async-storage-mock')
);

jest.mock("react-native-device-info", () => {
 return {
  getMode: jest.fn().mockImplementation(() => {
   return {}
  })
 }
})

jest.mock('react-native-webview', () => 'WebView');
