/**
 * @format
 */

import 'react-native';

// Note: test renderer must be required after react-native.
import { render } from '@testing-library/react-native';

import { ResourceCenter } from 'pages/Info/ResourceCenter';

it('renders correctly', () => {
  const tree = render(<ResourceCenter />).toJSON();
  expect(tree).toMatchSnapshot();
});
