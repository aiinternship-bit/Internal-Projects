/**
 * @format
 */

import 'react-native';

// Note: test renderer must be required after react-native.
import { render } from '@testing-library/react-native';

import { ComingSoon } from 'components/ComingSoon';

it('renders correctly', () => {
  const tree = render(<ComingSoon />).toJSON();
  expect(tree).toMatchSnapshot();
});
