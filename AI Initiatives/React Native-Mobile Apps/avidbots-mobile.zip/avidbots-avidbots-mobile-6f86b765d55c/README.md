# Avidbots Mobile

Welcome to the Avidbots Mobile. This document explains how to setup avidbots-mobile and how it is structured and how to start developing for it.

### Directory and file structure

```bash
avidbots-mobile/
├── __test__/                # contains tests scripts
├── .husky/                  # husky improves your commits and more. You can use it to lint your commit messages, run tests, lint code
├── .idea/                   # contains a set of configuration files (. xml) for your project
├── .vscode/                 # configurations for vscode
├── android/                 # contains android build (updates on every code change)
├── ios/                     # common ios build (updates on every code change)
├── patches/                 # holds any patches that the developer applied to module
├── src/                     # app code
|── ● .eslintignore          # file(s) to be ignored by eslint
|── ● .eslintrc.json         # pluggable and configurable linter tool for identifying and reporting on patterns in JavaScript.
|── ● .gitignore             # used to exclude file(s) while committing the code to git repository
|── ● .prettierignore        # file(s) to be ignored by prettier formatter
|── ● .prettierrc.json       # configuration for prettier formtter.
|── ● app.json               # base app config like name, version, etc.
|── ● babel.config.json      # babel config file
|── ● gradlew                # this file is the core component of your build process and has all of the instructions necessary to compile an Android app from source.babel config file
|── ● gradlew.bat            # a shell script and a Windows batch script for executing the build with the Wrapper
|── ● index.js               # entry point for the app
|── ● metro.config.json      # react native uses metro to build javascript code and assets
|── ● package.json           # contains all the dependencies required to run the project
|── ● react-native-config.js # allows you to set up different configuration files for different environment
|── ● tsconfig.json          # specifies the root files and compiler options required to compile the project
└── ● README.md              # Instructions !!!
```

## Prerequisites

- Follow [React-Native-Setup](https://reactnative.dev/docs/environment-setup) to configure android studio and environment variables
- Install Android Studio
- Set up and run atleast one virtual device to preview app while developing
  - Open Android Studio
  - From welcome page navigate to More Actions > Virtual Device Manager
  - Then click on Create Device and select any of the available configurations
- Make sure to check if Environment Variable "ANDROID_HOME" is set to correct path in the system

## IOS Setup

Installing Dependencies

- Please install [Brew](https://brew.sh/). Brew is a package manager for MacOS or Linux
  ```
  brew install node          #If you have already installed Node on your system, make sure it is Node 18 or newer.
  brew install watchman      # Watchman is a tool by Facebook for watching changes in the filesystem.
  ```
- Installing XCode
  - Download XCode from [Mac App Store](https://itunes.apple.com/us/app/xcode/id497799835?mt=12). Installing Xcode will also install the IOS Simulator and all the necessary tools to build your IOS app. If you have already installed Xcode on your system, make sure it is version 10 or newer.
  - You will also need to install the Xcode Command Line Tools. Open Xcode, then choose Settings... (or Preferences...) from the Xcode menu. Go to the Locations panel and install the tools by selecting the most recent version in the Command Line Tools dropdown.CocoaPods is one of the dependency management system available for iOS. CocoaPods is a Ruby gem. You can install CocoaPods using the version of Ruby that ships with the latest version of macOS.
  - [CocoaPods](https://cocoapods.org/) is one of the dependency management system available for iOS. CocoaPods is a Ruby gem. You can install CocoaPods using the version of Ruby that ships with the latest version of macOS.

## Running your React Native application

- Clone the repo
- In android folder create a file "local.properties" and add `sdk.dir = /home/<user>/Android/Sdk` or `sdk.dir = <path to your android SDK>`, this defines the android SDK path the app should point to.
- For IOS go to ios directory `cd ios` and run `pod install`, this will install the required pods for ios.
- `  npm install`
- `  npm start` (script to run react native app is included package.json)
- If everything went well, app will be previewed on virtual device. (Make sure virtual device is set up and is running. Initial run takes time, subsequent builds will be faster)

## That's it!

Congratulations! You've successfully run React Native app.

![Congratulations](https://reactnative.dev/docs/assets/GettingStartedCongratulations.png)

## Building Android APK

- navigate to android folder inside root folder
- Run command `./gradlew assembleDebug`
- APK file will be generated in path `/android/app/build/outputs/apk/debug/app-debug.apk`

## Building app for iOS

Unlike Android, iOS is bit different process to build or distribute the app. Only signed builds can be distributed.
For internal testing/distribution, tools like App Center should be used.

- Register as an Apple Developer

- Create a Certificate Signing Request (CSR) and Provisioning Profile

- Create app in App centre and configure build configuration as required

- Upload CSR and Provisioning Profile under Sign builds section in build configuration. This is mandatory as only sign builds can be distributed over iOS

- Trigger build manually or on every push.

For App store distribution, similar process needs to be followed in app store configuration.

## Eslint & Prettier Setup

- ESlint - ESLint is a tool for identifying and reporting on patterns found in ECMAScript/JavaScript code. Download VS code plugin [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)

- Prettier - is an opinionated code formatter. It enforces a consistent style by parsing your code and re-printing it with its own rules that take the maximum line length into account, wrapping code when necessary. [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)

## Notes

- Icons that can be used, [Feather Icons](https://feathericons.com/)
