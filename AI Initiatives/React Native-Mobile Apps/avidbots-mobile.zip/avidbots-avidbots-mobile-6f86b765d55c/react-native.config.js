module.exports = {
	project: {
		ios:{},
		android:{}
	},
	assets:['./src/app/assets/fonts/'],
};